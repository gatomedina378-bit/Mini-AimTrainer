package com.example.miniaimtrainer;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.content.*;
import java.util.*;

public class MainActivity extends Activity {
    AimView aim;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        aim = new AimView(this);
        setContentView(aim);
    }

    static class AimView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Random r = new Random();
        float x=300,y=500, radius=55;
        int score=0, shots=0, hits=0;
        long start=System.currentTimeMillis();
        boolean running=true;
        float tx=1.8f, ty=1.3f;

        AimView(Context c) { super(c); p.setTypeface(Typeface.create("sans",Typeface.BOLD)); setBackgroundColor(Color.BLACK); }

        void newTarget() {
            int w=getWidth(), h=getHeight();
            radius = 38 + r.nextInt(35);
            x = radius + r.nextFloat() * Math.max(1,w-2*radius);
            y = 150 + radius + r.nextFloat() * Math.max(1,h-230-2*radius);
            tx = (r.nextBoolean()?1:-1) * (1.2f+r.nextFloat()*2.5f);
            ty = (r.nextBoolean()?1:-1) * (0.8f+r.nextFloat()*2.2f);
        }

        protected void onDraw(Canvas c) {
            super.onDraw(c);
            p.setStyle(Paint.Style.FILL); p.setColor(Color.WHITE);
            p.setTextSize(38); c.drawText("MINI AIM TRAINER",24,52,p);
            p.setTextSize(24); c.drawText("Puntos: "+score+"   Precisión: "+(shots==0?0:(hits*100/shots))+"%",24,88,p);
            p.setTextSize(18); p.setColor(Color.LTGRAY);
            c.drawText("Tocá los objetivos • 60 segundos",24,116,p);

            p.setColor(Color.WHITE); c.drawCircle(x,y,radius,p);
            p.setColor(Color.BLACK); c.drawCircle(x,y,radius*0.62f,p);
            p.setColor(Color.WHITE); c.drawCircle(x,y,radius*0.27f,p);

            long left=60000-(System.currentTimeMillis()-start);
            if(left<=0) {
                running=false; p.setColor(Color.WHITE); p.setTextSize(42);
                c.drawText("¡TIEMPO!",getWidth()/2-90,getHeight()/2,p);
                p.setTextSize(25); c.drawText("Puntaje: "+score,getWidth()/2-65,getHeight()/2+45,p);
                c.drawText("Tocá para reiniciar",getWidth()/2-105,getHeight()/2+90,p);
            } else {
                x+=tx; y+=ty;
                if(x<radius || x>getWidth()-radius) tx=-tx;
                if(y<145+radius || y>getHeight()-radius) ty=-ty;
                postInvalidateDelayed(16);
            }
        }

        public boolean onTouchEvent(android.view.MotionEvent e) {
            if(e.getAction()!=MotionEvent.ACTION_DOWN) return true;
            if(!running) { score=shots=hits=0; start=System.currentTimeMillis(); running=true; newTarget(); invalidate(); return true; }
            shots++;
            float dx=e.getX()-x, dy=e.getY()-y;
            if(dx*dx+dy*dy<=radius*radius) { hits++; score+=10; newTarget(); }
            else score=Math.max(0,score-2);
            invalidate(); return true;
        }
    }
}
