MINI AIM TRAINER
================

App Android independiente para practicar puntería.
No modifica ni se conecta a Project Samel ni a ningún otro juego.

Para compilar:
1. Abrí esta carpeta en Android Studio.
2. Esperá a que Gradle termine de sincronizar.
3. Ejecutá en tu teléfono con depuración USB o generá un APK desde:
   Build > Build App Bundle(s) / APK(s) > Build APK(s)

Controles:
- Tocá los objetivos.
- Dura 60 segundos.
- Se muestran puntos y precisión.
